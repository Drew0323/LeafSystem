let sortTemp;
let newSortTemp;
let table = Dom.id('table');
let $table = $('#table');
let queryKey = {};
let typeArr = '1,2,3,4,-1,-2';

// //如果是移动端则禁用表格拖拽排序
// if(Util.Valid.isMobile()) {
//     table.setAttribute('data-reorderable-rows','false');
//     // $table.bootstrapTable('hideColumn', 'sort_icon');//隐藏某列
// }

//表格示例配置
// let example = {
//     url: '../data/login_info2.json',    //url一般是请求后台的url地址,调用ajax获取数据。此处我用本地的json数据来填充表格。
//     method: "get",                      //使用get请求到服务器获取数据
//     dataType: "json",
//     contentType: 'application/json,charset=utf-8',
//     toolbar: "#toolbar",                //一个jQuery 选择器，指明自定义的toolbar 例如:#toolbar, .toolbar.
//     uniqueId: "id",                    //每一行的唯一标识，一般为主键列
//     height: document.body.clientHeight-165,   //动态获取高度值，可以使表格自适应页面
//     cache: false,                       // 不缓存
//     striped: true,                      // 隔行加亮
//     queryParamsType: "limit",           //设置为"undefined",可以获取pageNumber，pageSize，searchText，sortName，sortOrder
//     //设置为"limit",符合 RESTFul 格式的参数,可以获取limit, offset, search, sort, order
//     queryParams: queryParams,
//     sidePagination: "server",           //分页方式：client客户端分页，server服务端分页（*）
//     // sortable: true,                   //是否启用排序;意味着整个表格都会排序
//     sortName: 'uid',                    // 设置默认排序为 name
//     sortOrder: "asc",                   //排序方式
//     pagination: true,                   //是否显示分页（*）
//     search: true,                       //是否显示表格搜索，此搜索是客户端搜索，不会进服务端，所以，个人感觉意义不大
//     strictSearch: true,
//     showColumns: true,                  //是否显示所有的列
//     showRefresh: true,                  //是否显示刷新按钮
//     showToggle:true,                    //是否显示详细视图和列表视图
//     clickToSelect: true,                //是否启用点击选中行
//     minimumCountColumns: 2,          //最少允许的列数 clickToSelect: true, //是否启用点击选中行
//     pageNumber: 1,                   //初始化加载第一页，默认第一页
//     pageSize: 10,                    //每页的记录行数（*）
//     pageList: [10, 25, 50, 100],     //可供选择的每页的行数（*）
//     paginationPreText: "Previous",
//     paginationNextText: "Next",
//     paginationFirstText: "First",
//     paginationLastText: "Last",
//     responseHandler: responseHandler,
//     columns: columns,
//     onLoadSuccess: function (data) { //加载成功时执行
//         console.log(data);
//     },
//         onLoadError: function (res) { //加载失败时执行
//             console.log(res);
//         }
//     }
$table.bootstrapTable({
    useRowAttrFunc: false, //设置拖动排序
    allowDragCellIndex: [0],//允许排序的单元格下标，空数组代表所有都可以排序
    pagination: true,//分页跳转页面
    paginationShowPageGo: true,//分页跳转页面
    //当选中行，拖拽时的哪行数据，并且可以获取这行数据的上一行数据和下一行数据
    onReorderRowsDrag: function(table,row) {
        sortTemp = table;
    },
    //拖拽完成后的这条数据，并且可以获取这行数据的上一行数据和下一行数据
    onReorderRowsDrop: function(table,row) {
        newSortTemp = table;
    },
    //当拖拽结束后，整个表格的数据
    onReorderRow: function(newData) {
        sort(sortTemp.menu_id,newSortTemp.sort);
    },
    // locale: 'zh-CN',//配置语言
    // height: 500,//设置高度，就可以固定表头
    url: '/system/api/menu/getMenuList',//请求地址
    responseHandler: function(res) {
        let result = {};
        result.rows = res.data;
        result.total = res.dataCount;
        return result;
    },
    fixedColumns: true,//固定列
    fixedNumber:2,//固定前两列
    pagination: true,//是否开启分页
    sidePagination: 'server',//是客户端分页还是服务端分页  'client','server',由于演示没有后端提供服务，所以采用前端分页演示
    pageNumber: 1,// 初始化加载第一页，默认第一页
    pageSize: 10,//默认显示几条
    pageList: [5, 10, 20, 30, 50, 100],//可供选择的每页的行数 - (亲测大于1000存在渲染问题)
    paginationLoop: true,//在上百页的情况下体验较好 - 能够显示首尾页
    paginationPagesBySide: 2,//展示首尾页的最小页数
    uniqueId: 'id',//唯一ID字段
    idField: 'id',//每行的唯一标识字段
    clickToSelect: true,//是否启用点击选中行
    showToggle: true,//是否显示详细视图和列表视图的切换按钮
    dataType: 'json',//请求得到的数据类型
    method: 'get',//请求方法
    toolbar: '#toolbar',//工具按钮容器
    // contentType: 'application/json,charset=utf-8',
    showColumns: true,//是否显示所有的列
    showRefresh: true,//是否显示刷新按钮
    showButtonIcons: true,//显示图标
    showButtonText: true,//显示文本
    showFullscreen: true,//显示全屏
    showPaginationSwitch: true,// 开关控制分页
    totalField: 'total',//总数字段
    undefinedText: '',//当字段为 undefined 显示
    search: false,//是否启用搜索框
    sortOrder: "asc",//排序方式
    buttonsClass: 'light',//按钮的类
    buttonsPrefix: 'btn',//类名前缀
    iconsPrefix: 'bi',//图标前缀
    iconSize: undefined,//图标大小 undefined sm lg
    icons: {
        fullscreen: 'bi-arrows-fullscreen',
        paginationSwitch: 'bi bi-caret-down-square',
        refresh: 'bi bi-arrow-clockwise',
        toggle: 'bi bi-toggle-off',
        columns: 'bi bi-list-ul'
    },
    onCheckAll: function(row) {batchBtnStatusHandle()},//全选复选框选中事件
    onCheck: function(row) {batchBtnStatusHandle()},//单行选中事件
    onUncheck: function(row) {batchBtnStatusHandle();},//单行取消选中事件
    onUncheckAll: function(row) {batchBtnStatusHandle()},//头部的那个复选框取消选中事件
    //加载模板
    loadingTemplate: function() {return '<div class="leaf-spinner text-primary"></div>';},
    //请求服务器的参数
    queryParams: function(params) {
        let reqParams = {
            type_arr: typeArr,
            // offset: params.offset,//sql语句起始索引
            PageNo: (params.offset / params.limit) + 1,
            PageCount: params.limit,//每页数据量
            SortField: params.sort,// 排序的列名
            SortOrder: params.order,// 排序方式 'asc' 'desc'
        };
        reqParams = {...reqParams, ...queryKey};//合并对象
        return reqParams;
    },
    //列
    columns: [{
        title: '',
        field: 'sort_icon',
        align: 'center',
        width: 3,
        widthUnit: 'rem',
        visible: false,
        formatter: function(val,rows) {
            return `<i class="bi bi-list"></i>`;
        }
    },{
        title: '操作',
        align: 'center',
        width: 80,
        widthUnit: 'px',
        class: 'operate',
        formatter: function (val, rows) {
            return `<button type="button" class="btn btn-link btn-sm leafsys-operate-view" data-bs-toggle="tooltip" data-bs-placement="top"
                        data-bs-title="查看"><i class="bi bi-eye"></i></button>
                    <button type="button" class="btn btn-link btn-sm leafsys-operate-edit PermissionKey-system_menu_updateMenuEdit" data-bs-toggle="tooltip" data-bs-placement="top"
                        data-bs-title="编辑"><i class="bi bi-pencil"></i></button>
                    <button type="button" class="btn btn-link btn-sm leafsys-operate-delete PermissionKey-system_menu_updateMenuDelete" data-bs-toggle="tooltip" data-bs-placement="top"
                        data-bs-title="删除"><i class="bi bi-trash3"></i></button>`;
        },
        //事件
        events: {
            'click .leafsys-operate-view': function(event, value, row, index) {
                BootstrapUtil.modal.iframe({
                    url: './edit.html?operate=View&id='+row.menu_id,
                    title: '查看菜单',
                    fullscreen: true
                });
            },
            'click .leafsys-operate-edit': function(event, value, row, index) {
                BootstrapUtil.modal.iframe({
                    url: './edit.html?operate=Edit&id='+row.menu_id,
                    title: '编辑菜单'
                });
            },
            'click .leafsys-operate-delete': function(event, value, row, index) {
                Modal.warning('确定要删除菜单【' + row.menu_name + '】以及它的子菜单?',{
                    buttons: ['取消','确定'],
                    click(index,e) {
                        if(index === '1') {
                            Ajax.post({url: '/system/api/menu/updateMenu?UpdateType=Delete',
                                param: {menu_id: row.menu_id},success(data) {
                                    if(data.IsSuccess === '1') {
                                        $table.bootstrapTable('refresh');
                                    } else {
                                        Modal.error(data.Msg);
                                    }
                                }
                            });
                        }
                    }
                });
            }
        }
    },{
        title: 'ID',
        field: 'menu_id',
        align: 'center',
        switchable: false,
        sortable: true,//是否作为排序列
        width: 80,
        widthUnit: 'px'
    },{
        title: '菜单名称',
        field: 'menu_name',
        align: 'left',
        sortable: true,//是否作为排序列
        width: 150,
        widthUnit: 'px',
        formatter(val,rows) {
            switch(rows.type) {
                case '1':
                    return `<b style="color: #bd9532">${val}</b>`;
                case '2':
                    return `<a href="javascript:window.parent.jumpPage(${rows.menu_id})" class="leafsys-a">${val}</a>`;
                case '3':
                    return `<a href="javascript:window.parent.location.href = '${rows.url}'" class="leafsys-a">${val}</a>`;
                case '4':
                    return `<a href="${rows.url}" class="leafsys-a" target="_blank">${val}</a>`;
            }
            return val;
        }
    },{
        title: '父级菜单ID',
        field: 'parent_menu_id',
        align: 'center',
        sortable: true,//是否作为排序列
        width: 80,
        widthUnit: 'px'
    },{
        title: '父级菜单名称',
        field: 'parent_menu_name',
        align: 'left',
        width: 150,
        widthUnit: 'px'
    },{
        title: '图标',
        field: 'menu_icon',
        align: 'center',
        width: 30,
        widthUnit: 'px',
        formatter(val,rows) {
            return `<i class="${val}" title="${val}"></i>`;
        }
    },{
        title: 'url',
        field: 'url',
        align: 'left',
        width: 160,
        widthUnit: 'px',
        visible: false,
        class: 'leafsys-line-break'
    }, {
        title: '类型',
        field: 'type',
        align: 'center',
        width: 60,
        widthUnit: 'px',
        formatter: function (val, rows) {
            switch (val) {
                case '1':
                    return '<span class="label label-yellow">菜单目录</span>';
                case '2':
                    return '<span class="label label-cyan">菜单项</span>';
                case '3':
                    return '<span class="label label-outline-cyan">此页面</span>';
                case '4':
                    return '<span class="label label-outline-info">新页面</span>';
                case '-1':
                    return '<span class="label label-info-light">按钮</span>';
                case '-2':
                    return '<span class="label label-purple-light">其他</span>';
            }
            return '';
        }
    },{
        title: '权限标识',
        field: 'permission_key',
        align: 'center',
        width: 60,
        widthUnit: 'px',
        visible: false
    },{
        title: '显示',
        field: 'is_show',
        align: 'center',
        width: 60,
        widthUnit: 'px',
        class: 'PermissionKey-system_menu_updateMenuIsShow',
        formatter: function(val,rows) {
            if(val === '1') {
                return '<label class="leaf-switch leaf-switch-solid"><input type="checkbox" checked class="leafsys-isShow"><span style="width: 25px;"></span></label>'
            } else {
                return '<label class="leaf-switch leaf-switch-solid"><input type="checkbox" class="leafsys-isShow"><span style="width: 25px;"></span></label>'
            }
        },
        events: {
            'change .leafsys-isShow': function (event, value, row, index) {
                Ajax.post({url: '/system/api/menu/updateMenu?UpdateType=IsShow',
                    param: {menu_id: row.menu_id,is_show: event.originalEvent.target.checked?1:0},success(data) {
                        if(data.IsSuccess !== '1') {
                            $table.bootstrapTable('refresh');
                            Modal.error(data.Msg);
                        }
                    }
                });
            }
        }
    },{
        title: '排序',
        field: 'sort',
        align: 'left',
        width: 160,
        widthUnit: 'px',
        class: 'PermissionKey-system_menu_updateMenuSort',
        sortable: true,
        formatter: function(val,rows) {
            return `<button type="button" class="btn btn-outline-primary btn-sm leafsys-sort-first" title="置顶"><i class="bi bi-align-top"></i></button>
                    <button type="button" class="btn btn-outline-primary btn-sm leafsys-sort-up" title="上移"><i class="bi bi-chevron-up"></i></button>
                    <button type="button" class="btn btn-outline-primary btn-sm leafsys-sort-down" title="下移"><i class="bi bi-chevron-down"></i></button>
                    <button type="button" class="btn btn-outline-primary btn-sm leafsys-sort-last" title="置底"><i class="bi bi-align-bottom"></i></button> ${val}`;
        },
        events: {
            'click .leafsys-sort-first': function(event, value, row, index) {
                event.stopPropagation();
                if(index === 0) return;
                sort(row.menu_id,$("#table").bootstrapTable('getData')[0].sort);
            },
            'click .leafsys-sort-up': function(event, value, row, index) {
                event.stopPropagation();
                let previous = $("#table").bootstrapTable('getData')[index-1];//上一条数据
                let previousSort = null;//上一条数据的sort字段
                //如果上一条数据为空
                if(previous === undefined) {
                    let curPageNumber = $table.bootstrapTable('getOptions').pageNumber;//当前页号
                    let curPageSize = $table.bootstrapTable('getOptions').pageSize;//当前页最大数量
                    if(curPageNumber === 1) {
                        Message.warning('这已经是第一条数据');
                        return;
                    }
                    //请求获取上一页的最后一条数据
                    Ajax.get({
                        url: $table.bootstrapTable('getOptions').url,
                        param: {
                            PageNo: curPageNumber - 1,
                            PageCount: curPageSize
                        },
                        success(data) {
                            if(data.IsSuccess === '1') {
                                previousSort = data.data[curPageSize - 1].sort;
                            } else {
                                Message.error('获取上一条数据失败');
                            }
                        },
                        async: false
                    });
                } else {
                    previousSort = previous.sort
                }

                sort(row.menu_id,previousSort);
            },
            'click .leafsys-sort-down': function(event, value, row, index) {
                event.stopPropagation();
                let next = $("#table").bootstrapTable("getData")[index+1];//下一条数据
                let nextSort = null;//上一条数据的sort字段
                //如果下一条数据为空
                if(next === undefined) {
                    let curPageNumber = $table.bootstrapTable('getOptions').pageNumber;//当前页号
                    let curPageSize = $table.bootstrapTable('getOptions').pageSize;//当前页最大数量
                    if(curPageNumber === $table.bootstrapTable('getOptions').totalPages) {
                        Message.warning('这已经是最后一条数据');
                        return;
                    }
                    //请求获取下一页的第一条数据
                    Ajax.get({
                        url: $table.bootstrapTable('getOptions').url,
                        param: {
                            PageNo: curPageNumber + 1,
                            PageCount: curPageSize
                        },
                        success(data) {
                            if(data.IsSuccess === '1') {
                                nextSort = data.data[0].sort;
                            } else {
                                Message.error('获取下一条数据失败');
                            }
                        },
                        async: false
                    });
                } else {
                    nextSort = next.sort
                }

                sort(row.menu_id,nextSort);
            },
            'click .leafsys-sort-last': function(event, value, row, index) {
                event.stopPropagation();
                let previous = $("#table").bootstrapTable('getData');//最后一条数据
                if(index === previous.length - 1) return;
                sort(row.menu_id,previous[previous.length - 1].sort);
            }
        }
    }]
});

// chosen下拉框组件初始化
$('.chosen-select').chosen();
// 添加chosen下拉框选择项
Dom.setMultipleSelectSelected('.leafsys-search-type',['1','2','3','4','-1','-2']);
$(".chosen-select").trigger("chosen:updated");//修改选中或添加项必须增加这一行

// 添加chosen下拉框变化监听
$('.leafsys-search-type').change(() => {
    typeArr = Dom.getMultipleSelectSelected('.leafsys-search-type').join(',');
    $table.bootstrapTable('selectPage', 1);//刷新回到第一页
});

// 添加按钮
Dom.css('.leafsys-operate-add').addEventListener('click',() => {
    BootstrapUtil.modal.iframe({
        url: './edit.html?operate=Add',
        title: '添加菜单',
        fullscreen: false
    });
});

// 查看菜单结构
Dom.css('.leafsys-viewMenuStructure').addEventListener('click',() => {
    BootstrapUtil.modal.iframe({
        url: './tree.html',
        title: '预览菜单',
        fullscreen: true
    });
});

// 是否启用拖拽排序
let isEnableDragSort = false;

Dom.css('.leafsys-isEnableDragSort').addEventListener('click',(e) => {
    // console.log($table.bootstrapTable('getOptions').useRowAttrFunc);//获取表格属性useRowAttrFunc
    isEnableDragSort = !isEnableDragSort;
    if(isEnableDragSort) {
        $table.bootstrapTable('refreshOptions',{
            useRowAttrFunc: true
        });
        $table.bootstrapTable('showColumn', 'sort_icon');//显示某列
        e.target.innerText = '[停用拖拽排序]';
    } else {
        $table.bootstrapTable('refreshOptions',{
            useRowAttrFunc: false
        });
        e.target.innerText = '[启用拖拽排序]';
        $table.bootstrapTable('hideColumn', 'sort_icon');//隐藏某列
    }
});

// 搜索处理
Dom.css('.leafsys-searchBtn').addEventListener('click',() => {
    queryKey = {};//把所有关键字都恢复默认值
    let searchKey = Dom.css('.leafsys-searchKey').value;
    let searchType= Dom.css('.leafsys-searchType').value;

    if(searchType == 0) {
        queryKey.menu_name = searchKey;
        queryKey.parent_menu_name = searchKey;
    } else {
        queryKey[searchType] = searchKey;
    }

    queryKey.is_show = Dom.css('.leafsys-search-isShow').value;
    // queryKey.type = Dom.css('.leafsys-search-type').value;
    queryKey.type_arr = Dom.getMultipleSelectSelected('.leafsys-search-type').join(",");
    queryKey.IsEqual = Dom.css('.leafsys-searchIsEqual').value;
    $table.bootstrapTable('selectPage', 1);//刷新回到第一页
});

// 重置处理
$('.leafsys-searchReset').on('click', function() {
    console.log($table.bootstrapTable('getOptions').sortName + ' - ' + $table.bootstrapTable('getOptions').sortOrder);
    //重置字段排序
    $table.bootstrapTable('refreshOptions',{
        sortName: null
    });
    queryKey = {};//把所有关键字都恢复默认值
    //刷新回到第一页
    $table.bootstrapTable('selectPage', 1);//刷新回到第一页
});

// 排序
function sort(id,newSort) {
    if($table.bootstrapTable('getOptions').sortName != null) {
        Modal.warning('当前存在字段处于排序状态！是否重置字段排序',{
            buttons: ['否','是'],
            click(index, e) {
                if(index === '1') {
                    //重置字段排序
                    $table.bootstrapTable('refreshOptions',{
                        sortName: null
                    });
                }
            }
        });
        return;
    }

    Ajax.post({
        url: '/system/api/menu/updateMenu?UpdateType=Sort',
        param: {menu_id: id,new_sort: newSort},
        success: function(data) {
            if(data.IsSuccess === '1') {
                $table.bootstrapTable('refresh');
            } else {
                Modal.error(data.Msg);
            }
        }
    });
}
//编辑后的回调函数
function editSuccess(text) {
    BootstrapUtil.modal.iframeClose();
    BootstrapUtil.modal.ok({
        body: text,
        cancelBtn: false
    });
}

//权限管理控件
addPermissionManagement(3);
