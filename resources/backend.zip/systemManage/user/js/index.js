function init(props, params) {
    let viewer = null,_this = null;

    new Vue({
        el: ".ls-container",
        data: {
            // 表格字段
            tableColumns: [{
                title: '操作',
                key: 'action',
                width: 120,
                // fixed: "left",
                scopedSlots: { customRender: 'action' }
            }, {
                title: '用户代码', dataIndex: 'user_id', key: 'user_id', align: 'center', width: 80
            }, {
                title: '名称', dataIndex: 'name', key: 'name', align: 'center', width: 120
            }, {
                title: '账号', dataIndex: 'account', key: 'account', width: 100
            }, {
                title: '头像', dataIndex: 'avatar', key: 'avatar', width: 70, scopedSlots: { customRender: 'avatar' }
            }, {
                title: '生日', dataIndex: 'birthday', key: 'birthday', align: "center", width: 100
            }, {
                title: '手机号', dataIndex: 'phone', key: 'phone', width: 100
            }, {
                title: '电子邮箱', dataIndex: 'email', key: 'email', width: 200
            }, {
                title: '真实姓名', dataIndex: 'real_name', key: 'real_name', width: 120
            }, {
                title: '身份证号', dataIndex: 'idcard', key: 'idcard', width: 200
            }, {
                title: '性别', dataIndex: 'sex', key: 'sex', width: 60, scopedSlots: { customRender: 'sex' }
            }, {
                title: '登录IP', dataIndex: 'login_ip', key: 'login_ip', width: 120
            }, {
                title: '登录时间', dataIndex: 'login_time', key: 'login_time', width: 150
            }, {
                title: '角色', dataIndex: 'role_list', key: 'role_list', width: 150, scopedSlots: { customRender: 'role_list' }
            }, {
                title: '禁用', dataIndex: 'is_disable', key: 'is_disable', width: 50, scopedSlots: { customRender: 'is_disable' }
            }],
            // 表格数据
            tableData: [],
            // 表格分页配置
            tablePagination: {
                pageSize: 10, // 每页显示的条数
                showSizeChanger: true, // 是否可以改变每页显示的条数
                pageSizeOptions: [1, 2, 5, 10, 30, 50, 100, 200, 300, 500, 600, 700, 800, 900, 1000], // 可选的每页显示条数
                showQuickJumper: true, // 是否可以快速跳转到指定页
                showTotal: total => `共 ${total} 条`, // 显示总条数和当前数据范围
                current: 1, // 当前页数
                total: 0 // 总条数
            },
            // 搜索配置
            searchConfig: {
                searchType: 'name',
                searchKey: '',
                IsEqual: '0',
                role_id_arr: [],
                model: {
                    is_disable: ''
                },
                params: {}
            },
            // 角色选择器
            roleSelect: {
                list: [],
                selectedIds: [],
                selectedItem: [],
                // 存储选中但不在options中的ID
                ghostOptions: [],
            },
            // 多选框
            // 选中的表格行key
            selectedRowKeys: [],
            selectedIds: []
        },
        created() {
            _this = this;
            // 修改分页事件
            this.tablePagination.onChange = (page, pageSize) => {
                this.loadTableList({
                    PageNo: page,
                    PageCount: pageSize
                });
            }
            // 修改分页大小事件
            this.tablePagination.onShowSizeChange = (page, pageSize) => {
                this.loadTableList({
                    PageNo: 1,
                    PageCount: pageSize
                });
            }

            // 加载数据
            this.loadTableList({
                PageNo: params.page?params.page:this.tablePagination.current,
                PageCount: params.pageSize?params.pageSize:this.tablePagination.pageSize
            });
        },
        mounted() {},
        methods: {
            // 加载表格列表
            loadTableList(params) {
                Ajax.get({
                    url: '/system/api/user/getUserList',
                    param: {...params, ...this.searchConfig.params},
                    success(result) {
                        if(result.IsSuccess === '1') {
                            _this.tableData = result.data;
                            _this.selectedRowKeys = [];
                            _this.selectedIds = [];
                            _this.tablePagination.total = result.dataCount;

                            // 等 DOM 渲染完再初始化 Viewer
                            _this.$nextTick(() => {
                                _this.initViewer();
                            });
                        } else {
                            _this.$message.error(result.Msg);
                        }
                    }
                });
                this.tablePagination.pageSize = params.PageCount;
                this.tablePagination.current = params.PageNo;
            },
            // 搜索
            search(isReset) {
                this.searchConfig.params = {};

                if (!isReset) {
                    this.searchConfig.params = this.searchConfig.model;
                    this.searchConfig.params[this.searchConfig.searchType] = this.searchConfig.searchKey;
                    this.searchConfig.params.role_id_arr = this.roleSelect.selectedIds.join(',');
                    this.tablePagination.current = 1;
                }

                this.loadTableList({
                    PageNo: 1,
                    PageCount: params.pageSize?params.pageSize:this.tablePagination.pageSize
                });
            },
            // 编辑表格
            edit(id,operate) {
                if (operate === 'Delete') {
                    Ajax.post({
                        url: '/system/api/user/updateUser?UpdateType=Delete',
                        param: {
                            user_id: id
                        },
                        success(result) {
                            if(result.IsSuccess === '1') {
                                _this.$message.success('删除成功');
                                _this.loadTableList({
                                    PageNo: _this.tablePagination.current,
                                    PageCount: _this.tablePagination.pageSize
                                });
                            } else {
                                _this.$message.error(result.Msg);
                            }
                        }
                    });
                    return;
                }
                let urls = props.url.split('/');
                urls.pop();
                let parentUrl = urls.join('/') + '/';
                QiankunUtil.toPage(parentUrl + 'edit.html', {
                    id: id,
                    operate: operate,
                    page: this.tablePagination.current,
                    pageSize: this.tablePagination.pageSize
                });
            },
            // 修改是否禁用
            updateIsDisable(id,isDisable) {
                isDisable = isDisable === '1'?'0':'1';

                for (let i = 0;i < _this.tableData.length;i++) {
                    if (_this.tableData[i].user_id === id) {
                        _this.tableData[i].is_disable = isDisable;
                        break;
                    }
                }

                Ajax.post({
                    url: '/system/api/user/updateUser?UpdateType=IsDisable',
                    param: {
                        user_id: id,
                        is_disable: isDisable
                    },
                    success(result) {
                        if(result.IsSuccess === '1') {
                            _this.$message.success('操作成功');
                        } else {
                            _this.$message.error(result.Msg);
                            _this.loadTableList({
                                PageNo: _this.tablePagination.current,
                                PageCount: _this.tablePagination.pageSize
                            });
                        }
                    }
                });
            },
            // 批量修改用户
            batchUpdateUser(updateType,value) {
                if (!this.selectedIds || this.selectedIds.length === 0) {
                    this.$message.error('请选择用户');
                    return;
                }

                let userIdArr = this.selectedIds.join(',');
                let param = {
                    UpdateType: updateType,
                    user_id_arr: userIdArr
                };

                if (updateType === 'IsDisable') {
                    param.is_disable = value;
                } else if (updateType === 'Sex') {
                    param.sex = value;
                } else if (updateType === 'Delete') {
                    this.$confirm({
                        title: '警告',
                        content: '确定删除代码为 [' + userIdArr + '] 的项？',
                        okText: '确定',
                        okType: 'danger',
                        cancelText: '取消',
                        onOk() {
                            Ajax.post({
                                url: '/system/api/user/batchUpdateUser?UpdateType=Delete',
                                param: param,
                                success(result) {
                                    if(result.IsSuccess === '1') {
                                        _this.$message.success('操作成功');
                                        _this.loadTableList({
                                            PageNo: _this.tablePagination.current,
                                            PageCount: _this.tablePagination.pageSize
                                        });
                                    } else {
                                        _this.$message.error(result.Msg);
                                    }
                                }
                            });
                        },
                        onCancel() {},
                    });
                    return;
                }

                Ajax.post({
                    url: '/system/api/user/batchUpdateUser?UpdateType=' + updateType,
                    param: param,
                    success(result) {
                        if(result.IsSuccess === '1') {
                            _this.$message.success('操作成功');
                            _this.loadTableList({
                                PageNo: _this.tablePagination.current,
                                PageCount: _this.tablePagination.pageSize
                            });
                        } else {
                            _this.$message.error(result.Msg);
                        }
                    }
                });
            },
            // 多选框变换事件
            onSelectChange(selectedKeys,selectedItems) {
                this.selectedRowKeys = selectedKeys;
                this.selectedIds = selectedItems.map(item => item.user_id);
            },
            // 初始化Viewer
            initViewer() {
                // 如果 viewer 已存在，销毁旧实例
                if (viewer) {
                    viewer.destroy();
                    viewer = null;
                }

                // 创建新的 Viewer 实例绑定当前页图片
                viewer = new Viewer(document.querySelector('.ant-table-tbody'), {
                    url: 'src',
                    filter(image) {
                        return image.tagName.toLowerCase() === 'img'; // 只预览 img 标签
                    }
                });

            },
            // 加载角色
            loadRoleSelect(searchKey) {
                let param = {
                    // PageNo: 1,
                    // PageCount: 2
                };

                if (searchKey) {
                    param = {
                        role_id: searchKey,
                        role_name: searchKey
                    };
                }

                Ajax.get({
                    url: '/system/api/role/getRoleList',
                    param: param,
                    success(result) {
                        if (result.IsSuccess === '1') {
                            _this.roleSelect.list = result.data;

                            // 分离出尚未加载的ID
                            // _this.roleSelect.selectedIds = _this.formData.role_list.map(item => item.role_id);
                            _this.roleSelect.ghostOptions = _this.roleSelect.selectedItem.filter(item =>
                                !result.data.some(role => role.role_id == item.role_id)
                            );
                        }
                    }
                });
            },
            roleSelectChange(selectedIds) {
                this.roleSelect.selectedIds = selectedIds;
                this.roleSelect.selectedItem = [...this.roleSelect.ghostOptions,...this.roleSelect.list]
                    .filter(role => selectedIds.some(id => role.role_id == id));
            },
            roleSelectSearch(key) {
                this.loadRoleSelect(key);
            },
            roleSelectFocus() {
                this.loadRoleSelect();
            },
        }
    });
}

// 获取qiankun子应用生命周期
QiankunUtil.getLifecycles({
    mount(props) {
        init(props, props.params);
    }
});